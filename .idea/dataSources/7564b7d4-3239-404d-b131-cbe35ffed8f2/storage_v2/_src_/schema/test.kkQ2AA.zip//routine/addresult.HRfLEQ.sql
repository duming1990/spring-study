create
    definer = root@localhost procedure addresult(IN age int)
BEGIN
 set age:=age+10;
 SELECT age;
END;

